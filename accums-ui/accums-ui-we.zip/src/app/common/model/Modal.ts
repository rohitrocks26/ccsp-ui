export class Modal {
    constructor(public modelHeader:string, public modelContent:string){
    this.modelHeader = modelHeader;
    this.modelContent = modelContent;
  }
}