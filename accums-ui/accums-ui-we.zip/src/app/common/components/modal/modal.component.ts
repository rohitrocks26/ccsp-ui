
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {
  @Input() modelinput ; 
  @Output() primaryButtonClicked : EventEmitter<any> = new EventEmitter();

  constructor() {}

  ngOnInit() { }
  primaryBtnClicked () {
    this.primaryButtonClicked.emit();
  }
}
