import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'app';
  public accumulatorTypes : Array<string> = [];
  constructor(private http : HttpClient) {}
  submit(redisData : any) {
    this.http.post('http://localhost:4000/api/redis', redisData )
    .subscribe(data=> console.log(data));

  }
  ngOnInit() {
    var paramObject = { };
    paramObject['key'] = 'CodeConfig';
    this.http.get('http://localhost:4000/api/redis', {params : paramObject})
    .subscribe(data=> this.accumulatorTypes = <Array<string>>data)
  }

}
