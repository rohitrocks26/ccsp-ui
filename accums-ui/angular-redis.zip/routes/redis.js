var express = require('express');
var router = express.Router();
var redis = require("redis");
var client = redis.createClient();

router.post('/', function(req, res, next) {
    console.log(req.body.key);
    client.set(req.body.key,req.body.value,redis.print);
    res.send('Successs');
});
router.get('/', function(req, res, next) {
    console.log('Reached Get');
    var key = req.query.key;
    client.lrange(key,0,-1, function(err, reply) {
    res.json(reply);
    });
});


module.exports = router;