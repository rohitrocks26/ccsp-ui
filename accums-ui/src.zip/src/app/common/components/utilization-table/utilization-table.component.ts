import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'utilization-table',
  templateUrl: './utilization-table.component.html',
  styleUrls: ['./utilization-table.component.scss']
})
export class UtilizationTableComponent implements OnInit {
  @Input() columns : Array<string>;
  @Input() memberUtilizationObject : any;
  constructor() { 
  }

  ngOnInit() {
    console.log(this.columns);
  }

}
