import { Component, OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  @Input() tabs:Array<any> = [];
  constructor() { }
  public classChanged:boolean=false;
  ngOnInit() {
    console.log(this.tabs);
  }
  toggleClass(event){
    this.classChanged=!this.classChanged;
  }
  activateLink(item : any) {
    var index = this.tabs.indexOf(item);
    this.tabs[index].active = true; 
    for(let i = 0 ; i < this.tabs.length ; i++) {
      if(i!=index) this.tabs[i].active = false;
    }
  }
}
